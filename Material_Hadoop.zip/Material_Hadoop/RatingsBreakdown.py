# Importamos mrjob
from mrjob.job import MRJob
from mrjob.step import MRStep

#Creamos la clase RatingBreakdown que extiende a mrjob
class RatingsBreakdown(MRJob):

    # Declaramos los steps indicando la función mapper y reducer
    def steps(self):
        return [
            MRStep(mapper=self.map_ratings,
                   reducer=self.reducer_count_ratings)
        ]

    # Definimos el método map_ratings 
    def map_ratings(self, _, line):
        # Cada línea contiene el valor de
        # los 4 atributos separados por tabulaciones
        (userID, movieID, rating, timestamp) = line.split('\t')
        # Devolvemos el par (rating, 1)
        yield rating, 1

    #Definimos el método reducer_count_ratings
    def reducer_count_ratings(self, key, values):
        # Para cada clave devolvemos la clave y 
        # la suma de valores
        yield key, sum(values)

if __name__ == '__main__':
    RatingsBreakdown.run()
